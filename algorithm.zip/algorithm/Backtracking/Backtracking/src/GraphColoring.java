import java.util.Scanner;

public class GraphColoring {

	public static int[][] g;
	public static int[] x;
	public static int n;
	public static int m;
	public static void mColoring(int k)
	{
		do
		{
			NextValue(k);      //find color for k vertex
			if(x[k] == 0)
				return;       //color paini
			if(k == n)        //sob gulay color hoise
			{
				for(int i=1; i<=n; i++)
				{
					System.out.print(x[i]+" ");
				}
				System.out.println();
			}
			else
				mColoring(k+1);        //poroborti vertex er color khujtesi
		}
		while(true);
	}
	public static void NextValue(int k)
	{
		do {
			x[k] = (x[k] + 1) % (m+1);
			if(x[k] == 0)
				return;
			int j;
			for(j=1; j<=n; j++)
			{
				if(g[k][j] != 0 && x[k] == x[j])
					break;
			}
			if(j == n+1)
				return;
		} while (true);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//GraphColoring gc = new GraphColoring();
		System.out.println("number of vertices:");
		n = sc.nextInt();
		g = new int[n+1][n+1];
		x = new int[n+1];
		System.out.println("maximum color:");
		m = sc.nextInt(); 
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<=n; j++)
			{
				g[i][j] = sc.nextInt();
			}
		}
		sc.close();
		mColoring(1);
	}
}
