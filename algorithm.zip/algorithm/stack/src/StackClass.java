


public class StackClass {
	int top;
	int size;
	int []a;
	public StackClass(int size)
	{
		this.size=size;
		a=new int[size];
		top=-1;
	}
	public int size()
	{
		return (top+1);
	}
	public boolean isEmptyStact()
	{
		return (top==-1);
	}
	public boolean isFullStack() {
		return (top==size-1);
		
	}
   public void add (int item) throws IllegalStateException{
	   if (isFullStack()) {
		   System.out.println("stack is full");
		
	}
	   else {
		a[++top]=item;
	}
   }
	  
		   
	   public int pop() throws IllegalStateException{
			if(isEmptyStact())
			{
				throw new IllegalStateException("stack underflow");
			}
			int  answer=a[top];
			a[top]=0;
			top--;
			return answer;
	   }
	   public void showStack()
		{
			for (int i =0; i<top+1; i++) {
				if(i==0)
				System.out.print(a[i]);
				else {
					System.out.print(","+a[i]);
				}
				
			}
		}
   
}
