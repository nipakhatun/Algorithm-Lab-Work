
public class Main {

	
	public static void main(String[] args) {
		StackClass s=new StackClass(5);
		s.add(4);
		s.add(5);
		s.add(1);
        s.pop();
		s.showStack();

	}

}
