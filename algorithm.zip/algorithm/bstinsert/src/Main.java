import java.util.Scanner;


public class Main {

	
	public static void main(String[] args) {
		BST bst=new BST();
		int i,n;
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		for ( i = 0; i <n; i++) {
			bst.insert(scanner.nextInt());
			
		}
		bst.preorder();
		
				
		
	}

}
