
public class BST {
	BSTNode root;
	public BST()
	{
		root=null;
	}
	public boolean isEmpty() {
		return (root==null);
		
	}
	//insert item
	public void insert(int data) {
		root=insert(root, data);
		
		
	}
	public BSTNode insert(BSTNode node,int data) {
		if (node==null) {
			node=new BSTNode(data);
			
		}
		else {
			if (data<=node.getData()) {
				node.left=insert(node.left, data);
				
			}
			else {
				node.right=insert(node.right, data);
				
			}
		}
		return node;
		
	}
	//searching a node
	public boolean search(int item) {
		return search(root, item);
		
	}
	public boolean search(BSTNode r,int item) {
		boolean found=false;
		while(r!=null&& !found)
		{
			int val=r.getData();
			if (item<val) {
				r=r.getLeft();
				
			}
			else if (item>val) {
				r=r.getRight();
				
			}
			else {
				found=true;
				break;
				
			}
			found=search(r, item);
		}
		return found;
		
		
	}
	public void preorder() {
		preorder(root);
		
	}
	public void preorder(BSTNode current) {
		if (current!=null) {
			System.out.print(current.getData()+" ");
			preorder(current.getLeft());
			preorder(current.getRight());
			
		}
		
	}

}
