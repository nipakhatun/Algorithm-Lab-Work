package stack;

public class LinkedStackMain {

	public static void main(String[] args) {
		LinkedStack<Integer> S = new LinkedStack<Integer>();
		//Here code for operation
		
	}
}
