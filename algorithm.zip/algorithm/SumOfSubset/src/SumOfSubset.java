import java.util.Scanner;


public class SumOfSubset {
	
	
	public void SumOfSub(int s,int k,int r,int capacity,int x[],int w[]) {
		//Scanner scanner=new Scanner(System.in);
		
		x[k]=1;
		if (s+w[k]==capacity) {
			for (int i = 0; i <=k; i++) {
				System.out.println(x[i]+" ");
				
			}
			System.out.println();			
		}
		else if (s+w[k]+w[k+1]<=capacity) {
			SumOfSub(s+w[k], k+1, r-w[k],capacity,x,w);			
			
		}
		if (s+r-w[k]>=capacity && s+w[k+1]<=capacity) {
			x[k]=0;
			SumOfSub(s, k+1, r-w[k],capacity,x,w);			
			
		}		
	}

	
	public static void main(String[] args) {
		
		
		
		Scanner scanner=new Scanner(System.in);
		SumOfSubset subset=new SumOfSubset();
		//int w[]=new int[100];
		int x[]=new int[100];
		int w[]=new int[100];
		System.out.println("no of elements:");
		
		int n=scanner.nextInt();
		int sum=0;
		
		//int w[] = new int [n];
		System.out.println("Input the numbers: ");
		for (int i = 0; i <n; i++) {
			w[i]=scanner.nextInt();
			sum=sum+w[i];
		}
		System.out.println("input limit:");
		int capacity=scanner.nextInt();
		subset.SumOfSub(0, 0, sum,capacity,x,w);
		
		
		
	}
	

}
