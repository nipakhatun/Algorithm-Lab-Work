
public class Main {

	
	public static void main(String[] args) {
		DynamicStack stack=new DynamicStack();
		stack.add(5);
		stack.add(1);
		stack.add(8);
		stack.delete(1);
		stack.printList();
	}

}
