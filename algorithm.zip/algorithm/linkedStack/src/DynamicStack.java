
public class DynamicStack {
	Node top;
	public DynamicStack()
	{
		top=null;
	}
	public void add(int item) {
		Node temp;
		temp=new Node();
		if (temp!=null){
			temp.setData(item);
			temp.setNext(top);
			top=temp;
			
		}
		else {
			System.out.println("out of space");
		}
			
}
	public boolean delete(int item)
	{
		if (top==null) {
			System.out.println("stack is empty");
			return false;
			
		}
		else {
			item=top.getData();
			top=top.getNext();
			return true;
		}
		
	}
	 public void printList()
	   {
	     Node node;
	     node= top;
	     
	     while (node!= null )
	     {
	       System.out.print(node.getData() + "  " );
	       node=node.getNext();
	     }
	   }

}
