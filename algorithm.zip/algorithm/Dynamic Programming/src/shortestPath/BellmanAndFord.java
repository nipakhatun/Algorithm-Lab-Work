package shortestPath;

import java.util.Scanner;

public class BellmanAndFord {

	public void BellmanFord(int v, int[][] cost, int[] dist, int n)
	//v= source vertex(1), cost = two dimensional array containing graph, dist=1 dimensional array, n=number of vertex
	{
		for(int i=1; i<=n; i++)
		{
			dist[i] = cost[v][i];           //1 number line er kaj
		}
		for(int k=2; k<=n-1; k++)          //2 theke n-1 porjonto
		{
			for(int u=1; u<=n; u++)        //u holo protita vertex
			{
				if(u!=v && checkEdge(u, cost, n)) 
				{
					for(int i=1; i<=n; i++)
					{
						if(dist[u] > dist[i] + cost[i][u])   //update dist if new dist is lower than previous dist
							dist[u] = dist[i] + cost[i][u];
					}
				}
			}
		}
	}
	//checking if u has at least one incoming edge
	public Boolean checkEdge(int u, int[][] cost, int n)
	{
		for(int i=1; i<=n; i++)
		{
			if(cost[i][u] != 0 || cost[i][u] != 99)
				return true;
		}
		return false;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BellmanAndFord bf = new BellmanAndFord();
		System.out.println("Number of vertex:");
		int n = sc.nextInt();
		int[][] graph = new int[n+1][n+1];
		System.out.println("Enter costs:");
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<=n; j++)
			{
				int in = sc.nextInt();
		
			    graph[i][j] = in;
			}
		}
		System.out.println("Source vertex:");
		int source = sc.nextInt();
		sc.close();
		int[] dist = new int[n+1];
		bf.BellmanFord(source, graph, dist, n);
		for(int i=1; i<=n; i++)
			System.out.print(dist[i]+" ");
		//System.out.println(bf.checkEdge(1, graph, n));
	}
}
