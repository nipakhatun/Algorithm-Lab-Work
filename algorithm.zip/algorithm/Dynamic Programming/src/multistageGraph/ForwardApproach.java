package multistageGraph;

import java.io.File;
import java.util.Scanner;

public class ForwardApproach {

	private void FGraph(int[][] c, int k, int n, int[] p)
	{
		int[] d = new int[n+1];
		d[n] = 0;
		int[] cost = new int[n+1];
		cost[n] = 0;
		for(int j=n-1; j>=1; j--)
		{
			int r = findVertex(j,c,n,cost);
			cost[j] = c[j][r] + cost[r];
			d[j] = r;
		}
		//find minimum cost path
		p[1] = 1;
		p[k] = n;
		for(int j=2; j<=k-1; j++)
		{
			p[j] = d[p[j-1]];
		}
	}
	private int findVertex(int j, int[][] c, int n, int[] cost) 
	{
		int min = 999;
		int vertex = 0;
		for(int r=1; r<=n; r++)
		{
			if(c[j][r] != 0)
			{
				if(c[j][r]+cost[r] < min)
				{
					min = c[j][r]+cost[r];
					vertex = r;
				}
			}
		}
		return vertex;
	}
	
	
}
