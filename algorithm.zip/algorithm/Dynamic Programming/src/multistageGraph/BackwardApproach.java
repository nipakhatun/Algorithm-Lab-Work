package multistageGraph;

import java.io.File;
import java.util.Scanner;

public class BackwardApproach {

	private void BGraph(int[][] c, int k, int n, int[] p)
	{
		int[] d = new int[n+1];
		d[1] = 0;
		int[] bcost = new int[n+1];
		bcost[1] = 0;
		for(int j=2; j<=n; j++)
		{
			int r = findVertex(j,c,n,bcost);
			System.out.println(r);
			bcost[j] = bcost[r]+c[r][j];
			d[j] = r;
			
		}
		//find minimum bcost path
		p[1] = 1;
		p[k] = n;
		for(int j=k-1; j>=2; j--)
		{
			p[j] = d[p[j+1]];
			
		}
	}
	private int findVertex(int j, int[][] c, int n, int[] bcost) 
	{
		int min = 999;
		int vertex = 0;
		for(int r=1; r<=n; r++)
		{
			if(c[r][j] != 0)
			{
				if(c[r][j]+bcost[r] < min)
				{
					min = c[r][j]+bcost[r];
					vertex = r;
				}
			}
		}
		return vertex;
	}
	
}
