package knapsackProblem;

public class Container {

	int p;
	int w;
	int sortingVariable;
	float x;
}
