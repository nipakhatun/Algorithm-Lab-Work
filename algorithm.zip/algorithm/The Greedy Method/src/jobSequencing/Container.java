package jobSequencing;

public class Container {

	public int p;
	public int d;
	public int s;
}
