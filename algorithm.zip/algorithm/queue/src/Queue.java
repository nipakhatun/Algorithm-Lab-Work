
public class Queue {
	public int[]data;
	public int front=-1;
	public int rear=-1;
	public int size=0;
	public Queue(int capacity)
	{
		data=new int[capacity];
		front=0;
		rear=-1;
		size=0;
		
	}
	public boolean isEmpty() {
		return(size==0);
		
	}
	public void add(int item) {
		if(size==data.length)
		{
			System.out.println("queue is full");
		}
		rear=(rear+1)%data.length;
		data[rear]=item;
		size++;
		
		
		
	}
	public void delete() {
		if (front==rear) {
          System.out.println("queue is empty");			
		}
		else {
			int item=data[front];
			data[front]=0;
			front=(front+1)%data.length;
			size=size-1;
			
		
		}
		
	}
	public void printqueue() {
		for (int i = 0; i <data.length; i++) {
			System.out.print(data[i]+" ");
			
		}
	}
		

}
