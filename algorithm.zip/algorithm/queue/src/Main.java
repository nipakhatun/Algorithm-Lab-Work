
public class Main {

	
	public static void main(String[] args) {
		Queue q=new Queue(5);
		q.add(3);
		q.add(1);
		q.add(7);
		
		q.delete();
		q.add(2);
		q.add(9);
		q.printqueue();
		

	}

}
