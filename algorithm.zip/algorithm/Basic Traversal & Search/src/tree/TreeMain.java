package tree;

public class TreeMain {

	public static void main(String[] args) {
		Traversal t = new Traversal();
		Node root = new Node('A');
		t.setRoot(root);
		t.root.setLchild('B');
		t.root.setRchild('C');
		t.root.getLchild().setLchild('D');
		t.root.getLchild().setRchild('E');
		t.root.getLchild().getLchild().setLchild('F');
		t.root.getLchild().getLchild().setRchild('G');
		t.root.getLchild().getLchild().getRchild().setLchild('H');
		t.root.getLchild().getLchild().getRchild().setRchild('I');
		System.out.println("InOrder:");
		t.inOrder(root);
		System.out.println("PreOrder:");
		t.preOrder(root);
		System.out.println("PostOrder:");
		t.postOrder(root);
		System.out.println("Triple Order:");
		t.Triple(root);
		//System.out.println("Triple Order nonrecursive:");
		//t.Trip(root);
	}
}
