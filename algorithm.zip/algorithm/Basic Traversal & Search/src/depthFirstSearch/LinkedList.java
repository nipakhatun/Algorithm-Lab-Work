package depthFirstSearch;

public class LinkedList {

	Node first,last;
	public LinkedList()
	{
		first = null;
		last = null;
	}
	public void insert(int item)
	{
		Node newNode = new Node(item, null);
		if(last == null)
		{
			first = last = newNode;
		}
		else
		{
			last.setLink(newNode);
			last = last.getLink();
		}
	}
	public Node getFirst()
	{
		return first;
	}
	public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Node i = first; i != null; i=i.getLink()) { //for#1
             if(i == first)
                  sb.append(i.getInfo());
             else
                  sb.append(", " + i.getInfo());
        }//end for#1
        
        return sb.toString();
   }//end toString
}
