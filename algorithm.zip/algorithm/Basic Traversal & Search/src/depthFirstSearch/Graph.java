package depthFirstSearch;

import java.io.File;
import java.util.Scanner;

public class Graph {
	static int size;
	static Boolean[] visited;
	static Node[] headNodes;

	private static void BFS(int v)
	{
		Stack s = new Stack(20);
		s.add(v);
		//s.print();
		//q.DeleteQ();
		//q.DeleteQ();
		//System.out.println(q.DeleteQ());
		visited = new Boolean[size+1];
		
		for(int i = 0; i <= size; i++)
            visited[i] = false;
		visited[v] = true;
		Node temp;
		int u;  //current vertex
		int w;  //it's adjacent vertices
		while(!s.isEmpty())
		{
		    u = s.Delete();
		    System.out.print(u+" ");
		    temp = headNodes[u];
		    while(temp!=null)
		    {
		    	w = temp.getInfo();
		    	if(visited[w] == false)
		    	{
		    		s.add(w);
		    		visited[w] = true;
		    	}
		    	temp = temp.getLink();
		    }
		    //s.print();
		}
	}
	private static void printGraph()
	{
		Node temp;
		for(int i=1; i<=size;i++)
		{
			System.out.print(i + "  ");
			temp = headNodes[i];
			while(temp!=null)
			{
				System.out.print(temp.getInfo() + "  ");
				temp = temp.getLink();
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		File f = new File("graph2.txt");
		try {
			Scanner sc = new Scanner(f);
			size = sc.nextInt();
			headNodes = new Node[size+1];
			int vertex;
			int adjacent;
			for(int i=1; i<=size; i++)
			{
				vertex = sc.nextInt();
				adjacent = sc.nextInt();
				LinkedList G = new LinkedList();
				while(adjacent != 0)
				{
					G.insert(adjacent);
					adjacent = sc.nextInt();
				}
				headNodes[vertex] = G.getFirst();
			}
			sc.close();
			
			BFS(1);
			//printGraph();
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		
	}
}
